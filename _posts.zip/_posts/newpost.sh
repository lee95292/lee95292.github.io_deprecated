#!/bin/bash
# Usage
# ./newposh.sh POSTtitle
DATE=`date "+%Y-%m-%d"`
TIME=`date "+%H:%M:%S"`

TITLE="${DATE}-${1}.markdown"

echo -e "---
layout : post
title : "\""$1"\""
date : ${DATE} ${TIME}
categories:
---" >> "DOING/$TITLE"